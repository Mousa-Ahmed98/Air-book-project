function toggleDivs() {
    var plusDiv = document.getElementById("plus");
    var minaceDiv = document.getElementById("minace");

    if (plusDiv.style.display === "none" ) {
        plusDiv.style.display = "block";
        minaceDiv.style.display = "none";
    } else {
        plusDiv.style.display = "none";
        minaceDiv.style.display = "block";
    }
}
function toggleDivs2() {
    var plusDiv2 = document.getElementById("plus2");
    var minaceDiv2 = document.getElementById("minace2");

    if (plusDiv2.style.display === "none" ) {
        plusDiv2.style.display = "block";
        minaceDiv2.style.display = "none";
    } else {
        plusDiv2.style.display = "none";
        minaceDiv2.style.display = "block";
    }
}
function toggleDivs3() {
    var plusDiv3 = document.getElementById("plus3");
    var minaceDiv3 = document.getElementById("minace3");

    if (plusDiv3.style.display === "none") {
        plusDiv3.style.display = "block";
        minaceDiv3.style.display = "none";
    } else {
        plusDiv3.style.display = "none";
        minaceDiv3.style.display = "block";
    }
}

var btnScroll=document.getElementById("btnScroll");
window.onscroll=function(){
    if (scrollY>=30)
    {
        btnScroll.style.display='block';

    }
    else{
        btnScroll.style.display='none';
    }
}

btnScroll.addEventListener('click',function(){
    scroll({
        top:0,
        left:0,
        behavior:"smooth",
    })

})

